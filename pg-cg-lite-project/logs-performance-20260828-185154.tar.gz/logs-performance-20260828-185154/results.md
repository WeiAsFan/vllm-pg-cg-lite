# PG-CG Lite formal performance experiment

Run directory: /mnt_d/pg-cg-lite-work-huangxiaoyuan/logs-performance-20260828-185154
Repository commit: c18d29d36a547cf0bda7c2e8b8a1cf2308c6c5de

## Method

Six isolated server runs were executed in the required order A1, B1, A2, B2, A3, B3. Every run read the same fixed 500-record JSONL manifest, 512 input tokens, 128 output tokens, concurrency 16, seed 2026, temperature 0, and ignore-eos.

## Per-round results

| Round | Config | Capture sizes | Capture time (s) | Capture memory (GiB) | Throughput (req/s) | Median TPOT (ms) | Completed | Failed | Validation |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| A1 | default | 35 | 3.0 | 0.35 | 3.889053145622732 | 25.9225662400319 | 500 | 0 | PASS |
| B1 | lite | 8 | 1.0 | 0.14 | 3.889005560070591 | 25.857656468375122 | 500 | 0 | PASS |
| A2 | default | 35 | 3.0 | 0.35 | 3.8852797416159985 | 26.110483877962146 | 500 | 0 | PASS |
| B2 | lite | 8 | 1.0 | 0.14 | 3.8876794816589157 | 26.04626796064407 | 500 | 0 | PASS |
| A3 | default | 35 | 3.0 | 0.35 | 3.8914424554255485 | 25.94241757091597 | 500 | 0 | PASS |
| B3 | lite | 8 | 1.0 | 0.14 | 3.882120724434665 | 26.60209574419492 | 500 | 0 | PASS |

## Aggregates

- Default mean request throughput: 3.888591780888093 req/s
- Lite mean request throughput: 3.8862685887213906 req/s
- Lite versus default throughput change: -0.05974379152167142 percent
- Default mean median TPOT: 25.991822562970007 ms
- Lite mean median TPOT: 26.16867339107137 ms
- Lite versus default median TPOT change: 0.6804094929199644 percent
- Batch Invariance diagnostic: PASS

## Acceptance criteria

- lite_capture_sizes_at_most_8: PASS
- lite_capture_sizes_fewer_than_default: PASS
- request_throughput_drop_at_most_5_percent: PASS
- median_tpot_increase_at_most_5_percent: PASS
- six_rounds_500_of_500: PASS
- no_severe_runtime_errors: PASS
- batch_invariance_diagnostic_passed: PASS

Overall result: PASS
